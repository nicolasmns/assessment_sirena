class LoggingOptionsInterface():
    def get_log(self, current_value):
        pass




